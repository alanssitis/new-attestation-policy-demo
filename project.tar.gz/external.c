#include "external.h"
#include <stdio.h>

void my_external_function()
{
    printf("safe hello world\n");
}
