#ifndef __EXTERNAL_H__
#define __EXTERNAL_H__

void my_external_function();

#endif
