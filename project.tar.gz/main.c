#include "external.h"

int main() {
    my_external_function();
}
